package com.cobra.linkguard

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF111A2B)
private val Red = Color(0xFFFF4057)
private val Cyan = Color(0xFF42D9E8)
private val Muted = Color(0xFF91A0B8)
private const val TELEGRAM = "https://t.me/C0braa_7777"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Red,
                secondary = Cyan, onBackground = Color.White, onSurface = Color.White
            )) {
                CobraApp(
                    openTelegram = {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM)))
                    }
                )
            }
        }
    }
}

@Composable
private fun CobraApp(openTelegram: () -> Unit) {
    var page by remember { mutableStateOf(0) }
    var url by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    var question by remember { mutableStateOf("") }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                NavigationBarItem(selected = page == 0, onClick = { page = 0 },
                    icon = { Icon(Icons.Default.Shield, null) }, label = { Text("الفحص") })
                NavigationBarItem(selected = page == 1, onClick = { page = 1 },
                    icon = { Icon(Icons.Default.AutoAwesome, null) }, label = { Text("Ask COBRA") })
                NavigationBarItem(selected = page == 2, onClick = { page = 2 },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text("الإعدادات") })
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Red, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Security, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("COBRA", fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("LINK GUARD  •  PREMIUM", color = Cyan, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
                Spacer(Modifier.weight(1f))
                Surface(color = Color(0xFF17313A), shape = RoundedCornerShape(50)) {
                    Text("● READY", color = Cyan, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                }
            }
            Spacer(Modifier.height(26.dp))
            when (page) {
                0 -> {
                    Text("حافظ على أمانك الرقمي", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("افحص الرابط قبل ما تفتحه", color = Muted, modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(22.dp))
                    CardBox {
                        Text("فحص رابط جديد", color = Cyan, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(14.dp))
                        OutlinedField(value = url, onValueChange = { url = it }, hint = "https://example.com")
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = {
                            result = when {
                                url.isBlank() -> "اكتب رابطًا أولًا"
                                !(url.startsWith("https://") || url.startsWith("http://")) -> "صيغة الرابط غير صحيحة"
                                else -> "تم التحقق من صيغة الرابط فقط. الفحص الأمني الحقيقي يحتاج ربط خدمة خارجية."
                            }
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Icon(Icons.Default.Search, null)
                            Spacer(Modifier.width(8.dp))
                            Text("افحص الرابط")
                        }
                        result?.let {
                            Spacer(Modifier.height(12.dp))
                            Text(it, color = if (it.startsWith("تم")) Cyan else Color.White, fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MiniStat("01", "تحقق من الصيغة", Modifier.weight(1f))
                        MiniStat("API", "فحص متقدم لاحقًا", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(18.dp))
                    CardBox {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, null, tint = Cyan)
                            Spacer(Modifier.width(10.dp))
                            Text("تنبيه أمني", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("النسخة الحالية تعرض نموذج الواجهة وتتحقق من صيغة الرابط فقط؛ لا تعتبر النتيجة شهادة بأن الرابط آمن.", color = Muted, fontSize = 13.sp)
                    }
                }
                1 -> {
                    Text("ASK COBRA", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Cyan)
                    Text("مساعدك لفهم الروابط والأمان الرقمي", color = Muted, modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(20.dp))
                    CardBox {
                        Icon(Icons.Default.AutoAwesome, null, tint = Red, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("اسأل COBRA", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("واجهة المساعد جاهزة. يلزم ربط Gemini أو نموذج ذكاء اصطناعي قبل تفعيل الإجابات الحقيقية.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                        Spacer(Modifier.height(16.dp))
                        OutlinedField(value = question, onValueChange = { question = it }, hint = "اكتب سؤالك هنا...")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { question = "" }, enabled = question.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Text("إرسال (يتطلب ربط الخدمة)")
                        }
                    }
                }
                else -> {
                    Text("الإعدادات", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("إدارة التطبيق والخدمات", color = Muted, modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(20.dp))
                    CardBox {
                        SettingLine("VirusTotal", "يتطلب API Key")
                        Divider(color = Color(0xFF263249), modifier = Modifier.padding(vertical = 12.dp))
                        SettingLine("Google Safe Browsing", "يتطلب API Key")
                        Divider(color = Color(0xFF263249), modifier = Modifier.padding(vertical = 12.dp))
                        SettingLine("Gemini AI", "يتطلب API Key")
                    }
                    Spacer(Modifier.height(16.dp))
                    CardBox {
                        Text("التواصل الرسمي", fontWeight = FontWeight.Bold)
                        Text("تيليجرام فقط", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = openTelegram, modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF168BC4))) {
                            Icon(Icons.Default.Send, null)
                            Spacer(Modifier.width(8.dp))
                            Text("@C0braa_7777")
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("COBRA Link Guard • الإصدار 1.0", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp))
        .border(1.dp, Color(0xFF253149), RoundedCornerShape(22.dp)).padding(18.dp), content = content)
}

@Composable
private fun OutlinedField(value: String, onValueChange: (String) -> Unit, hint: String) {
    Row(Modifier.fillMaxWidth().background(Bg, RoundedCornerShape(13.dp))
        .border(1.dp, Color(0xFF33415B), RoundedCornerShape(13.dp)).padding(15.dp)) {
        Box {
            if (value.isEmpty()) Text(hint, color = Muted, fontSize = 14.sp)
            BasicTextField(value, onValueChange, singleLine = true, textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp))
        }
    }
}

@Composable
private fun MiniStat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(value, color = Red, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text(label, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun SettingLine(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.Lock, null, tint = Muted)
    }
}
