# COBRA Link Guard — مشروع مبدئي

هذا مشروع Android أصلي باستخدام Kotlin وJetpack Compose، بتصميم Premium Dark.

## الموجود حاليًا
- شاشة فحص الروابط: تتحقق من صيغة الرابط فقط.
- شاشة Ask COBRA: واجهة أولية غير متصلة بنموذج ذكاء اصطناعي.
- شاشة إعدادات تعرض الخدمات التي تحتاج مفاتيح API.
- زر تيليجرام يفتح https://t.me/C0braa_7777
- إزالة روابط YouTube وInstagram.

## ما لم يتم تنفيذه بعد
- فحص السمعة الحقيقي عبر VirusTotal أو Google Safe Browsing.
- ردود Gemini الحقيقية.
- تخزين آمن لمفاتيح API.
- اختبارات على أجهزة فعلية.

لا تعرض نتيجة فحص الصيغة على أنها فحص أمني. يلزم ربط خدمات السمعة قبل تقديم تصنيف آمن/خطر.

## البناء
يتطلب Android Studio حديثًا وAndroid SDK 35 وGradle 8.9 أو متوافقًا.
افتح المجلد في Android Studio ثم نفّذ Sync Project with Gradle Files، وبعدها Build > Build APK(s).

التطبيق يستخدم package id جديدًا: `com.cobra.linkguard`، لذلك يثبت كتطبيق مستقل ولا يستبدل النسخة القديمة.
